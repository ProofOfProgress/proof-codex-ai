"""Blender property definitions for Proscenium addon state."""

import json

import bpy
from bpy.app.handlers import persistent
from bpy.props import (
    BoolProperty,
    CollectionProperty,
    EnumProperty,
    FloatProperty,
    FloatVectorProperty,
    IntProperty,
    PointerProperty,
    StringProperty,
)
from bpy.types import AddonPreferences, PropertyGroup


# ---------------------------------------------------------------------------
# Per-armature prompt-block persistence
# ---------------------------------------------------------------------------

_BLOCKS_KEY = "proscenium_prompt_blocks"
_ACTIVE_KEY = "proscenium_active_block_index"


def _serialize_blocks(blocks) -> str:
    return json.dumps([
        {
            "prompt": b.prompt,
            "frame_start": b.frame_start,
            "frame_end": b.frame_end,
            "enabled": b.enabled,
            "color": list(b.color),
            "seed": int(getattr(b, "seed", 0)),
            "last_used_seed": int(getattr(b, "last_used_seed", 0)),
        }
        for b in blocks
    ])


def save_blocks_to_armature(arm_obj, settings):
    """Pickle prompt_blocks + active_block_index onto the armature's ID props."""
    if arm_obj is None:
        return
    try:
        _ = arm_obj.name
    except ReferenceError:
        return
    arm_obj[_BLOCKS_KEY] = _serialize_blocks(settings.prompt_blocks)
    arm_obj[_ACTIVE_KEY] = int(settings.active_block_index)


def load_blocks_from_armature(arm_obj, settings):
    """Replace settings.prompt_blocks with the serialized list on *arm_obj*.
    If the armature has no stored blocks, creates a single default block
    spanning the scene frame range."""
    settings.prompt_blocks.clear()
    if arm_obj is None:
        settings.active_block_index = 0
        return

    raw = arm_obj.get(_BLOCKS_KEY)
    if raw:
        try:
            data = json.loads(raw)
        except (json.JSONDecodeError, TypeError):
            data = []
        for item in data:
            b = settings.prompt_blocks.add()
            b.prompt = item.get("prompt", "")
            b.frame_start = int(item.get("frame_start", 1))
            b.frame_end = int(item.get("frame_end", 250))
            b.enabled = bool(item.get("enabled", True))
            color = item.get("color") or [0, 0, 0, 0]
            b.color = color[:4] + [0] * (4 - len(color))
            # ``seed`` was added with per-block regenerate; older scenes serialised
            # without it default to 0 (= "server picks a random seed").
            b.seed = int(item.get("seed", 0))
            # ``last_used_seed`` records the concrete seed of the last generation
            # (added with client-side seed recording); older scenes default to 0.
            b.last_used_seed = int(item.get("last_used_seed", 0))
        settings.active_block_index = int(arm_obj.get(_ACTIVE_KEY, 0))
        return

    # No stored data — seed with one default block covering the scene range.
    scene = bpy.context.scene
    b = settings.prompt_blocks.add()
    b.prompt = ""
    b.frame_start = scene.frame_start
    b.frame_end = scene.frame_end
    b.enabled = True
    settings.active_block_index = 0


def _preview_path_snap_update(self, context):
    """When the user flips the "Snap to Path" toggle on, immediately sync
    the current curve's control points into root-bone location keyframes.

    Without this the depsgraph handler only fires on the NEXT curve edit,
    which makes the checkbox feel dead when you first turn it on.
    Turning the toggle off is a no-op: keyframes stay where they are.
    """
    if not self.preview_path_snap:
        return
    if getattr(self, "is_generating", False) or getattr(self, "is_previewing", False):
        # Do not replace dense preview-bake root keys with sparse curve keys;
        # see ``path_follow._snap_skips_target_during_generation_preview``.
        return
    arm = self.target_armature
    if arm is None or arm.type != 'ARMATURE':
        return
    # Local import — properties.py would otherwise drag path_follow into
    # registration order and we'd hit a circular load when the addon
    # loads properties first.
    from . import path_follow
    curve = path_follow._find_root_path_curve(context.scene)
    if curve is not None:
        path_follow.sync_path_to_armature(arm, context.scene, curve)


# ---------------------------------------------------------------------------
# Target armature lifecycle
# ---------------------------------------------------------------------------

def _is_live_armature(obj) -> bool:
    """``True`` iff ``obj`` is an armature linked into the scene tree.

    Three failure modes to catch:

    1. **Dangling wrapper** — any RNA access raises ``ReferenceError``
       (``getattr`` does not catch it).
    2. **Not in ``bpy.data``** — the ID was fully removed but Blender did
       not auto-clear the ``PointerProperty``.
    3. **Orphan datablock** — the object is still in ``bpy.data`` but
       every collection has dropped it. A multi-object delete leaves the
       deleted rig in this state until Blender's garbage pass purges it;
       the single-object delete path either purges immediately or fires
       the RNA update callback, which is why this code never tripped
       before.
    """
    if obj is None:
        return False
    try:
        if obj.type != 'ARMATURE':
            return False
        name = obj.name
        if bpy.data.objects.get(name) is not obj:
            return False
        return bool(obj.users_collection)
    except (ReferenceError, AttributeError):
        return False


def _live_armature(obj):
    """Return ``obj`` if it is a live armature, else ``None``."""
    return obj if _is_live_armature(obj) else None


def _redraw_proscenium_editors() -> None:
    """Tag every editor so the picker and timeline reflect the new state.

    Tagging only ``VIEW_3D`` / ``DOPESHEET_EDITOR`` is enough in theory, but
    the sidebar panel can sit in a region that does not redraw until a
    broader tag, and properties-editor mirrors can hold the stale name
    in their cached UI. Tag everything — it is cheap.
    """
    wm = bpy.context.window_manager
    if wm is None:
        return
    for win in wm.windows:
        for area in win.screen.areas:
            area.tag_redraw()


_pending_reset_scene_names: set[str] = set()


def schedule_target_reset(scene_name: str) -> None:
    """Queue a one-shot timer to reset stale target state on ``scene_name``.

    Draw callbacks (panels, gpu overlays) must never mutate scene
    properties directly. When such a callback notices that
    ``target_armature`` is dangling but the depsgraph handler has not
    fired yet, it calls this to defer the cleanup to the next app tick.
    """
    if not scene_name or scene_name in _pending_reset_scene_names:
        return
    _pending_reset_scene_names.add(scene_name)

    def _flush():
        try:
            sc = bpy.data.scenes.get(scene_name)
            if sc is None:
                return None
            settings = getattr(sc, "proscenium", None)
            if settings is None:
                return None
            if _scene_needs_target_reset(settings):
                reset_target_armature_state(settings)
        finally:
            _pending_reset_scene_names.discard(scene_name)
        return None

    bpy.app.timers.register(_flush, first_interval=0.0)


_in_target_reset = False


def reset_target_armature_state(settings) -> None:
    """Wipe every piece of scene state bound to the target armature.

    Called when the rig was deleted, when the user clears the picker, or when
    the file loads with no target set. Idempotent and re-entrancy-safe: the
    ``settings.target_armature = None`` assignment fires the update callback,
    which re-enters this helper; the ``_in_target_reset`` flag makes the
    nested call a no-op.
    """
    global _in_target_reset
    if _in_target_reset:
        return
    _in_target_reset = True
    try:
        if settings.target_armature is not None:
            settings.target_armature = None
        if settings.previous_target_armature is not None:
            settings.previous_target_armature = None
        settings.is_previewing = False
        settings.source_action_name = ""
        settings.prompt_blocks.clear()
        settings.active_block_index = 0
    finally:
        _in_target_reset = False
    _redraw_proscenium_editors()


def _target_armature_update(self, context):
    """Sync per-armature state when the picker changes.

    Three cases:
      * picker cleared (or rig deleted, since Blender auto-clears the
        pointer) → wipe scene state via ``reset_target_armature_state``;
      * picker switched to a different rig → persist the previous rig's
        prompt blocks, then load the new rig's;
      * idempotent re-assignment (same id) → no-op.
    """
    if _in_target_reset:
        return

    settings = context.scene.proscenium
    new_arm = _live_armature(settings.target_armature)
    old_arm = _live_armature(settings.previous_target_armature)

    if new_arm is None:
        reset_target_armature_state(settings)
        return

    if new_arm is old_arm:
        return

    if old_arm is not None:
        try:
            save_blocks_to_armature(old_arm, settings)
        except ReferenceError:
            pass

    # Preview / Accept-Reject bookkeeping is tied to the rig that was baked,
    # so switching rigs always invalidates it.
    settings.is_previewing = False
    settings.source_action_name = ""

    load_blocks_from_armature(new_arm, settings)
    settings.previous_target_armature = new_arm
    _redraw_proscenium_editors()


def _inplace_update(self, context):
    """Live toggle for In-place mode — adds or removes a Limit Location
    constraint on the target armature's root bone. The constraint pins
    bone-local X / Z to 0 (Y free), so the character animates in place
    horizontally while vertical motion (jumps, crouches) still plays.

    Non-destructive: fcurves are untouched, flipping the toggle off
    restores the original travel without re-generating. The constraint
    only lives during preview; Accept zeroes the xz keyframes and removes
    the constraint, baking the in-place result into the final actions.

    Imports operators lazily to dodge the circular ``properties ->
    operators -> properties`` chain at module load.
    """
    arm = self.target_armature
    if arm is None or arm.type != 'ARMATURE':
        return
    from . import operators  # noqa: PLC0415 — lazy to avoid circular import
    operators._apply_inplace_constraint(arm, enabled=bool(self.inplace))

    # Tag the depsgraph so the viewport reflects the constraint change.
    arm.update_tag()


# ---------------------------------------------------------------------------
# Classes
# ---------------------------------------------------------------------------


class PromptBlock(PropertyGroup):
    """One frame-range window with a text prompt, drawn on the timeline."""

    prompt: StringProperty(
        name="Prompt",
        description="Text prompt driving generation for this time window",
        default="",
    )
    frame_start: IntProperty(
        name="Start Frame",
        description="First frame of this range (inclusive)",
        default=1, min=1,
    )
    frame_end: IntProperty(
        name="End Frame",
        description="Last frame of this range (inclusive)",
        default=250, min=1,
    )
    enabled: BoolProperty(
        name="Enabled",
        description="Include this block when generating",
        default=True,
    )
    color: FloatVectorProperty(
        name="Color",
        description="Display color for this strip (0,0,0,0 = auto palette)",
        subtype="COLOR",
        size=4,
        min=0.0, max=1.0,
        default=(0.0, 0.0, 0.0, 0.0),
    )
    seed: IntProperty(
        name="Seed",
        description=(
            "Per-block seed override. 0 = inherit the global Seed, so setting "
            "the global Seed reproduces the whole clip. Set a positive value to "
            "give this block its own seed — when the connected model advertises "
            "per-segment seeds, full-timeline Generate honours it so this block "
            "re-rolls independently of the others"
        ),
        default=0, min=0, max=999999,
    )
    last_used_seed: IntProperty(
        name="Last Used Seed",
        description=(
            "The concrete seed this block was last generated with (0 = not "
            "generated yet). When Seed is 0, the addon rolls a real seed at "
            "generation time and records it here so the result is reproducible "
            "— right-click the strip and choose 'Reuse seed' to lock it in"
        ),
        default=0, min=0, max=999999,
    )


# Animatica Cloud's MMCP endpoint. Surfaced as a non-editable label in the
# prefs UI; users opt in to a self-hosted override via the `self_hosted`
# checkbox. Resolved at request time by mmcp_client.get_server_url().
CLOUD_API_URL = "https://api.animatica.ai"


class ProsceniumAddonPreferences(AddonPreferences):
    """Addon-level preferences — edit in ``Edit > Preferences > Add-ons > Proscenium``."""

    bl_idname = __package__  # "proscenium_blender"

    self_hosted: BoolProperty(
        name="Self-hosted",
        default=False,
        description=(
            "Tick when running an MMCP server on your own machine or LAN "
            "(e.g. motionmcp-kimodo on localhost). Untick to use Animatica "
            "Cloud at api.animatica.ai (default; requires sign-in)."
        ),
    )
    server_url: StringProperty(
        name="Server URL",
        default="http://localhost:8000",
        description="Base URL of your self-hosted MMCP server",
    )

    # --- Animatica Cloud session (populated by /auth/login) ----------------
    # Auth is NOT part of the MMCP protocol — it lives at the cloud's proxy
    # in front of /generate. Self-hosted servers ignore the Authorization
    # header entirely.
    access_token: StringProperty(
        name="Access Token",
        default="",
        description="Animatica session token; valid for ~1 hour, then auto-refreshed",
        subtype='PASSWORD',
    )
    refresh_token: StringProperty(
        name="Refresh Token",
        default="",
        description="Long-lived refresh token used to renew the session",
        subtype='PASSWORD',
    )
    email: StringProperty(
        name="Email",
        default="",
        description="Email of the signed-in Animatica user",
    )
    tier: StringProperty(
        name="Tier",
        default="",
        description="Animatica plan tier (free / pro / team / admin)",
    )

    def draw(self, context):
        from . import mmcp_client

        layout = self.layout

        # --- Server selection -------------------------------------------------
        col = layout.column(align=True)
        col.label(text="Server", icon='WORLD_DATA')

        # Cloud URL: always visible, never editable.
        row = col.row(align=True)
        row.enabled = False
        row.label(text=f"Animatica Cloud — {CLOUD_API_URL}/")

        col.prop(self, "self_hosted")
        if self.self_hosted:
            col.prop(self, "server_url", text="Override URL")

        # --- Connection status + connect/reconnect ----------------------------
        layout.separator()
        caps = mmcp_client.cached_capabilities()
        box = layout.box()
        if caps is None:
            err = mmcp_client.last_connection_error()
            if err:
                box.label(text="Connection failed", icon='ERROR')
                for line in err.split("\n")[:3]:
                    box.label(text=line)
            else:
                box.label(text="Not connected", icon='UNLINKED')
            box.operator("proscenium.connect", icon='URL', text="Connect")
        else:
            n_models = len(caps.get("models", []))
            row = box.row()
            row.label(text=f"Connected — {n_models} model(s)", icon='LINKED')
            row.operator("proscenium.connect", icon='FILE_REFRESH', text="Reconnect")

            proto = caps.get("protocol_version", "?")
            box.label(text=f"MMCP {proto} · {caps.get('coordinate_system', '?')} · {caps.get('units', '?')}")

            for m in caps.get("models", []):
                mbox = box.box()
                mbox.label(text=m.get("id", "?"), icon='OUTLINER_OB_ARMATURE')
                joints = len(m.get("canonical_skeleton", {}).get("joints", []))
                fps = m.get("fps", "?")
                retarget = "yes" if m.get("supports_retargeting") else "no"
                mbox.label(text=f"{joints} joints @ {fps} fps · retargeting: {retarget}")

                segs = ", ".join(m.get("supported_segments") or []) or "—"
                mbox.label(text=f"segments: {segs}")
                cons = ", ".join(m.get("supported_constraints") or []) or "—"
                mbox.label(text=f"constraints: {cons}")

                limits = m.get("limits") or {}
                max_dur = limits.get("max_duration_seconds")
                rec_dur = m.get("recommended_max_duration_seconds")
                if max_dur is not None or rec_dur is not None:
                    parts = []
                    if rec_dur is not None:
                        parts.append(f"recommended ≤ {rec_dur:g}s")
                    if max_dur is not None:
                        parts.append(f"max {max_dur:g}s")
                    mbox.label(text=" · ".join(parts))

        layout.separator()

        # --- Auth section -----------------------------------------------------
        if self.self_hosted:
            box = layout.box()
            box.label(text="Self-hosted: sign-in not required", icon='INFO')
            return

        if self.access_token:
            box = layout.box()
            row = box.row()
            row.label(text=f"Signed in: {self.email}", icon='CHECKMARK')
            if self.tier:
                row.label(text=f"({self.tier})")
            row = box.row()
            row.operator("proscenium.signout", icon='X', text="Sign out")
        else:
            box = layout.box()
            box.label(text="Animatica Cloud — sign in", icon='USER')
            box.operator("proscenium.signin", icon='IMPORT', text="Sign in")


def _model_id_items(self, context):
    """Dynamic EnumProperty items, populated by the Connect operator."""
    from . import mmcp_client
    return mmcp_client.cached_model_items()


class ProsceniumSettings(PropertyGroup):
    """Scene-level addon state."""

    # -- MMCP server connection --
    model_id: EnumProperty(
        name="Model",
        description="Motion-generation model exposed by the connected MMCP server",
        items=_model_id_items,
    )

    # -- Target armature --
    target_armature: PointerProperty(
        name="Target Armature",
        type=bpy.types.Object,
        description="Armature with keyframed animation to generate from",
        poll=lambda self, obj: obj.type == 'ARMATURE',
        update=_target_armature_update,
    )

    previous_target_armature: PointerProperty(
        name="Previous Target Armature",
        type=bpy.types.Object,
        options={"HIDDEN", "SKIP_SAVE"},
    )

    # -- Prompt blocks (one time-window with one prompt each) --
    prompt_blocks: CollectionProperty(
        type=PromptBlock,
        name="Prompt Blocks",
        description="Per-window prompts drawn as strips on the timeline",
    )
    active_block_index: IntProperty(
        name="Active Block",
        default=0, min=0,
    )

    # -- Generation settings --
    seed: IntProperty(
        name="Seed",
        description=(
            "Clip seed used for every block that doesn't pin its own. The same "
            "seed with the same inputs reproduces the same motion. 0 = roll a "
            "fresh random seed each run (recorded below so you can lock it in)"
        ),
        default=42, min=0, max=999999,
    )
    last_used_seed: IntProperty(
        name="Last Used Seed",
        description=(
            "The concrete clip seed the last generation actually ran with "
            "(0 = none yet). Set when Seed is 0 and a fresh seed was rolled; "
            "click the lock to copy it into Seed and reproduce the run"
        ),
        default=0, min=0, max=999999,
    )

    quality_preset: EnumProperty(
        name="Quality",
        items=[
            ("STANDARD", "Standard", "50 denoising steps"),
            ("HALF", "Half", "25 denoising steps"),
            ("QUARTER", "Quarter", "12 denoising steps"),
            ("CUSTOM", "Custom", "Custom step count"),
        ],
        default="STANDARD",
    )
    custom_steps: IntProperty(
        name="Steps", default=50, min=1, max=200,
    )

    cfg_enabled: BoolProperty(
        name="Guidance (CFG)",
        description=(
            "Enable classifier-free guidance. When on, generation is pushed "
            "to follow your prompt and constraints more closely; turn it off "
            "for the model's looser, unguided output"
        ),
        default=True,
    )
    cfg_text: FloatProperty(
        name="Text Weight",
        description=(
            "How strongly the motion follows the text prompt. Higher is more "
            "literal to the words but can look stiff; lower is more natural "
            "but looser. Typical range 1–3"
        ),
        default=2.0, min=0.0, max=5.0, step=10,
    )
    cfg_constraint: FloatProperty(
        name="Constraint Weight",
        description=(
            "How strongly the motion honors your constraints — root paths, "
            "effector pins, and pose keyframes. Higher sticks tighter to the "
            "poses and paths you authored. Typical range 1–3"
        ),
        default=2.0, min=0.0, max=5.0, step=10,
    )

    post_processing: BoolProperty(
        name="Motion Cleanup",
        description=(
            "Run server-side motion correction after generation: tightens "
            "keyframe pins, fixes foot sliding, enforces end-effector "
            "constraints. Requires the server to have the motion_correction "
            "package installed. Safe to enable; adds a second or two per "
            "sample"
        ),
        default=True,
    )
    inplace: BoolProperty(
        name="In place",
        description=(
            "Suppress the root bone's horizontal translation so the "
            "character animates in place instead of travelling through "
            "the scene. Vertical motion (jumps, crouches) is kept. Toggle "
            "live after generation — the xz keyframes are kept but muted, "
            "so switching back off restores the original travel without "
            "re-generating. Useful for game-style cycles (walk loops, "
            "idles) where the root motion comes from a controller"
        ),
        default=False,
        update=_inplace_update,
    )
    preview_path_snap: BoolProperty(
        name="Snap to Path",
        description=(
            "Bake each root_path curve control point into one keyframe on "
            "the target armature's root bone. Turning this on syncs "
            "immediately from the current curve; leaving it on keeps the "
            "keyframes in sync as you edit the curve in the viewport. "
            "While a generation is running or a preview bake is active, "
            "sync is paused so the returned root trajectory is not replaced "
            "by sparse path keys (which looks like snapping and foot sliding)"
        ),
        default=True,
        update=_preview_path_snap_update,
    )
    num_transition_frames: IntProperty(
        name="Transition Frames",
        description=(
            "Frames blended between adjacent prompt blocks so segments flow "
            "smoothly into one another instead of snapping at the boundary. "
            "0 = hard cut between blocks"
        ),
        default=5, min=0, max=30,
    )

    default_prompt: StringProperty(
        name="Prompt",
        default="a person moves naturally",
        description="Text prompt for motion generation",
    )

    last_pose_prompt: StringProperty(
        name="Last pose prompt",
        default="a person stands in a neutral pose",
        description=(
            "Most-recent prompt used in the Generate Pose dialog. "
            "Pre-fills the dialog the next time it opens so the user "
            "can iterate on a phrasing without retyping"
        ),
    )

    # -- Runtime state (not saved) --
    is_generating: BoolProperty(name="Generating", default=False)
    generation_progress: FloatProperty(
        name="Progress", default=0.0, min=0.0, max=1.0, subtype='FACTOR',
    )
    # Seconds elapsed since the in-flight generation started. There is no
    # server-side progress signal in MMCP v1, so the panel shows this as a
    # live "Working… Ns" counter instead of a progress bar that would sit
    # frozen at 0%. Updated from the generate / pose / regenerate modals.
    generation_elapsed: IntProperty(
        name="Elapsed Seconds",
        default=0,
        options={"SKIP_SAVE"},
    )
    cancel_requested: BoolProperty(
        name="Cancel Requested",
        default=False,
        description="Flipped by the Cancel button; the running modal op picks it up and exits",
    )

    # -- Quota / upgrade state. Set when the cloud returns 429
    #    quota_exceeded; cleared on the next successful generation or
    #    when the user dismisses the banner. ``upgrade_url`` is sent in
    #    the error envelope so the plugin doesn't hardcode a billing URL.
    quota_exceeded_message: StringProperty(
        name="Quota Message",
        default="",
        description="Human-readable quota error message from the cloud",
    )
    quota_upgrade_url: StringProperty(
        name="Upgrade URL",
        default="",
        description="URL to open in the user's browser to upgrade the plan",
    )

    # -- Preview state: name of the user's source action while a
    #    Proscenium_Motion (or legacy Proscenium_Generated) action is
    #    being previewed.  Empty when free-form generation runs (no
    #    source to fall back to) — the ``is_previewing`` flag tracks
    #    preview state independently for that case.
    source_action_name: StringProperty(
        name="Source Action",
        default="",
        description="Original action name preserved while previewing a generated motion",
    )
    is_previewing: BoolProperty(
        name="Previewing",
        default=False,
        description=(
            "Set true while a Proscenium-generated motion is being "
            "reviewed (Push to NLA / Reject visible). Independent of "
            "source_action_name so free-form generations — where "
            "there's no prior action to restore — also surface the "
            "preview UI"
        ),
    )


# ---------------------------------------------------------------------------
# Depsgraph — catch armature deletions that bypass the RNA update callback
# ---------------------------------------------------------------------------

def _purge_stale_depsgraph_handlers(handler_list, fn_name: str) -> None:
    for h in list(handler_list):
        if getattr(h, "__name__", None) == fn_name:
            handler_list.remove(h)


def _scene_needs_target_reset(s) -> bool:
    """True if scene state is inconsistent with a live target armature.

    Triggers cleanup when:
      * ``target_armature`` is a dangling wrapper (single-object delete on
        rigs that did not survive Blender's auto-remap);
      * ``target_armature`` is ``None`` but per-target state lingers — the
        case that breaks multi-object delete, where Blender silently
        clears the pointer to ``None`` without firing the RNA update
        callback, leaving ``previous_target_armature`` / ``prompt_blocks``
        / preview flags untouched.
    """
    try:
        target = s.target_armature
    except ReferenceError:
        return True
    if target is not None:
        return not _is_live_armature(target)

    try:
        if s.previous_target_armature is not None:
            return True
    except ReferenceError:
        return True
    if len(s.prompt_blocks) > 0:
        return True
    if s.is_previewing or s.source_action_name:
        return True
    return False


@persistent
def _validate_target_armature_on_depsgraph(_scene, _depsgraph) -> None:
    """Drop dangling ``target_armature`` pointers and any per-target state
    that survives them. Runs on every depsgraph tick; the actual reset
    is idempotent so the cost when nothing changed is a few attribute
    reads per scene."""
    for scene in bpy.data.scenes:
        s = getattr(scene, "proscenium", None)
        if s is None:
            continue
        if _scene_needs_target_reset(s):
            reset_target_armature_state(s)


# ---------------------------------------------------------------------------
# Registration
# ---------------------------------------------------------------------------

_classes = (
    ProsceniumAddonPreferences,
    PromptBlock,
    ProsceniumSettings,
)

_DEPSGRAPH_HANDLER_NAME = "_validate_target_armature_on_depsgraph"


def register():
    for cls in _classes:
        bpy.utils.register_class(cls)
    bpy.types.Scene.proscenium = PointerProperty(type=ProsceniumSettings)
    _purge_stale_depsgraph_handlers(
        bpy.app.handlers.depsgraph_update_post, _DEPSGRAPH_HANDLER_NAME,
    )
    bpy.app.handlers.depsgraph_update_post.append(
        _validate_target_armature_on_depsgraph,
    )


def unregister():
    _purge_stale_depsgraph_handlers(
        bpy.app.handlers.depsgraph_update_post, _DEPSGRAPH_HANDLER_NAME,
    )
    del bpy.types.Scene.proscenium
    for cls in reversed(_classes):
        bpy.utils.unregister_class(cls)
